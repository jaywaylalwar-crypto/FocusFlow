# FocusFlow demo script (target: 2 minutes 30 seconds)

**0:00–0:15 — Intro**
“Hi, this is FocusFlow, a study productivity dashboard designed to help students plan tasks, log study sessions, and understand their study habits.”

**0:15–0:45 — Overview**
Show the four metrics and subject chart. Explain that the numbers are based on recorded sessions and tasks.

**0:45–1:10 — Tasks**
Add a task called “Revise Python loops”, set its subject and priority, then mark it complete.

**1:10–1:35 — Study session**
Log a 25-minute Python session and show the updated history.

**1:35–2:05 — Insights**
Open Study Insights and show the time trend, subject breakdown, and rule-based recommendations.

**2:05–2:20 — Export**
Download the CSV session history.

**2:20–2:30 — Wrap-up**
“FocusFlow is a prototype. The next step is validating and demonstrating any required product-specific integration for the selected hackathon track.”
