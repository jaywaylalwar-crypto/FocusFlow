import json
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd
import streamlit as st

APP_DIR = Path(__file__).parent
DATA_DIR = APP_DIR / "data"
TASKS_FILE = DATA_DIR / "tasks.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"

st.set_page_config(page_title="FocusFlow | Study Insights", page_icon="🎯", layout="wide")

def load_json(path, default):
    DATA_DIR.mkdir(exist_ok=True)
    if not path.exists():
        path.write_text(json.dumps(default, indent=2))
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return default

def save_json(path, value):
    DATA_DIR.mkdir(exist_ok=True)
    path.write_text(json.dumps(value, indent=2))

def seed_demo_data():
    tasks = load_json(TASKS_FILE, [])
    sessions = load_json(SESSIONS_FILE, [])
    if not tasks and not sessions:
        today = date.today()
        tasks = [
            {"id": 1, "title": "Revise Python functions", "subject": "Python", "due_date": str(today), "priority": "High", "done": False},
            {"id": 2, "title": "Practice Java OOP questions", "subject": "Java", "due_date": str(today + timedelta(days=1)), "priority": "Medium", "done": True},
            {"id": 3, "title": "Review C pointers", "subject": "C", "due_date": str(today + timedelta(days=2)), "priority": "High", "done": False},
            {"id": 4, "title": "Build a Power BI chart", "subject": "Power BI", "due_date": str(today + timedelta(days=3)), "priority": "Low", "done": False},
        ]
        sessions = [
            {"date": str(today - timedelta(days=6)), "subject": "Python", "minutes": 45, "notes": "Functions"},
            {"date": str(today - timedelta(days=5)), "subject": "Java", "minutes": 60, "notes": "Classes and objects"},
            {"date": str(today - timedelta(days=4)), "subject": "C", "minutes": 35, "notes": "Pointers"},
            {"date": str(today - timedelta(days=3)), "subject": "Python", "minutes": 50, "notes": "Pandas"},
            {"date": str(today - timedelta(days=2)), "subject": "Power BI", "minutes": 40, "notes": "Charts"},
            {"date": str(today - timedelta(days=1)), "subject": "Java", "minutes": 55, "notes": "Inheritance"},
            {"date": str(today), "subject": "Python", "minutes": 30, "notes": "Practice"},
        ]
        save_json(TASKS_FILE, tasks)
        save_json(SESSIONS_FILE, sessions)

seed_demo_data()
tasks = load_json(TASKS_FILE, [])
sessions = load_json(SESSIONS_FILE, [])

st.markdown("""
<style>
.block-container {padding-top: 1.8rem; padding-bottom: 2.5rem; max-width: 1400px;}
.hero {padding: 1.35rem 1.5rem; border-radius: 18px; background: linear-gradient(120deg,#18233f,#254d6e); color: white; margin-bottom: 1rem;}
.hero h1 {margin:0; font-size:2.2rem;} .hero p {margin:.35rem 0 0 0; opacity:.88;}
.small-note {color:#667085; font-size:.9rem;}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="hero"><h1>🎯 FocusFlow</h1><p>Your study planner, session tracker, and productivity insights — all in one place.</p></div>', unsafe_allow_html=True)

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Go to", ["Overview", "Tasks", "Study Sessions", "Study Insights", "About"])
    st.divider()
    st.caption("FocusFlow • Hackathon prototype")
    if st.button("Reset to demo data", use_container_width=True):
        for p in (TASKS_FILE, SESSIONS_FILE):
            if p.exists():
                p.unlink()
        seed_demo_data()
        st.rerun()

tasks = load_json(TASKS_FILE, [])
sessions = load_json(SESSIONS_FILE, [])
sessions_df = pd.DataFrame(sessions)
if not sessions_df.empty:
    sessions_df["date"] = pd.to_datetime(sessions_df["date"], errors="coerce")
    sessions_df["minutes"] = pd.to_numeric(sessions_df["minutes"], errors="coerce").fillna(0)
    sessions_df["hours"] = sessions_df["minutes"] / 60
    sessions_df = sessions_df.dropna(subset=["date"])

done_count = sum(1 for t in tasks if t.get("done"))
task_count = len(tasks)
completion = round(done_count / task_count * 100) if task_count else 0
total_minutes = int(sessions_df["minutes"].sum()) if not sessions_df.empty else 0
week_start = pd.Timestamp(date.today() - timedelta(days=6))
week_minutes = int(sessions_df.loc[sessions_df["date"] >= week_start, "minutes"].sum()) if not sessions_df.empty else 0

if page == "Overview":
    st.subheader("Your progress at a glance")
    a, b, c, d = st.columns(4)
    a.metric("Study time logged", f"{total_minutes/60:.1f} hrs")
    b.metric("Last 7 days", f"{week_minutes/60:.1f} hrs")
    c.metric("Tasks completed", f"{done_count}/{task_count}")
    d.metric("Completion rate", f"{completion}%")
    left, right = st.columns([1.35, 1])
    with left:
        st.markdown("### Study time by subject")
        if not sessions_df.empty:
            by_subject = sessions_df.groupby("subject", as_index=False)["hours"].sum().sort_values("hours", ascending=False)
            st.bar_chart(by_subject.set_index("subject"))
        else:
            st.info("Log a study session to see your chart.")
    with right:
        st.markdown("### Next tasks")
        upcoming = sorted([t for t in tasks if not t.get("done")], key=lambda t: t.get("due_date", "9999"))
        if upcoming:
            for t in upcoming[:5]:
                st.write(f"**{t['title']}**")
                st.caption(f"{t.get('subject','General')} · Due {t.get('due_date','No date')} · {t.get('priority','Medium')} priority")
        else:
            st.success("Everything is completed. Nice work!")
    st.markdown("### Quick insight")
    if not sessions_df.empty:
        recent = sessions_df[sessions_df["date"] >= week_start]
        if recent.empty:
            st.info("No study sessions in the last 7 days yet. Add a short session to start building your trend.")
        else:
            top = recent.groupby("subject")["minutes"].sum().idxmax()
            st.info(f"You've logged {week_minutes/60:.1f} study hours in the last 7 days. **{top}** has received the most study time.")
    else:
        st.info("Start logging sessions to unlock personalized study insights.")

elif page == "Tasks":
    st.subheader("Task planner")
    with st.expander("＋ Add a task", expanded=True):
        with st.form("add_task", clear_on_submit=True):
            title = st.text_input("Task title", placeholder="e.g., Practice Python loops")
            subject = st.selectbox("Subject", ["Python", "Java", "C", "Power BI", "Computer Networks", "Other"])
            due = st.date_input("Due date", value=date.today())
            priority = st.selectbox("Priority", ["High", "Medium", "Low"], index=1)
            submitted = st.form_submit_button("Add task", type="primary")
            if submitted:
                if not title.strip():
                    st.error("Enter a task title first.")
                else:
                    next_id = max([t.get("id", 0) for t in tasks], default=0) + 1
                    tasks.append({"id": next_id, "title": title.strip(), "subject": subject, "due_date": str(due), "priority": priority, "done": False})
                    save_json(TASKS_FILE, tasks)
                    st.success("Task added.")
                    st.rerun()
    if tasks:
        st.markdown("### Your tasks")
        for task in tasks:
            cols = st.columns([0.08, 0.54, 0.19, 0.12, 0.12])
            checked = cols[0].checkbox("Done", value=task.get("done", False), key=f"done_{task['id']}", label_visibility="collapsed")
            if checked != task.get("done", False):
                task["done"] = checked
                save_json(TASKS_FILE, tasks)
                st.rerun()
            label = f"~~{task['title']}~~" if task.get("done") else f"**{task['title']}**"
            cols[1].markdown(label)
            cols[1].caption(task.get("subject", "General"))
            cols[2].write(task.get("due_date", "—"))
            cols[3].write(task.get("priority", "Medium"))
            if cols[4].button("Delete", key=f"del_{task['id']}"):
                tasks = [t for t in tasks if t["id"] != task["id"]]
                save_json(TASKS_FILE, tasks)
                st.rerun()
    else:
        st.info("No tasks yet. Add your first task above.")

elif page == "Study Sessions":
    st.subheader("Log a study session")
    with st.form("add_session", clear_on_submit=True):
        col1, col2 = st.columns(2)
        session_date = col1.date_input("Date", value=date.today())
        subject = col2.selectbox("Subject", ["Python", "Java", "C", "Power BI", "Computer Networks", "Other"])
        minutes = st.number_input("Duration (minutes)", min_value=5, max_value=720, value=30, step=5)
        notes = st.text_input("What did you study? (optional)")
        submitted = st.form_submit_button("Save session", type="primary")
        if submitted:
            sessions.append({"date": str(session_date), "subject": subject, "minutes": int(minutes), "notes": notes.strip()})
            save_json(SESSIONS_FILE, sessions)
            st.success("Session saved.")
            st.rerun()
    st.markdown("### Session history")
    if not sessions_df.empty:
        display_df = sessions_df.sort_values("date", ascending=False)[["date", "subject", "minutes", "notes"]].copy()
        display_df["date"] = display_df["date"].dt.strftime("%Y-%m-%d")
        st.dataframe(display_df, use_container_width=True, hide_index=True)
        csv = display_df.to_csv(index=False).encode("utf-8")
        st.download_button("Download session history (CSV)", csv, "focusflow_sessions.csv", "text/csv")
    else:
        st.info("No sessions logged yet.")

elif page == "Study Insights":
    st.subheader("Study insights")
    if sessions_df.empty:
        st.info("Log at least one study session to see insights.")
    else:
        today_ts = pd.Timestamp(date.today())
        last7 = sessions_df[sessions_df["date"] >= today_ts - pd.Timedelta(days=6)]
        last14 = sessions_df[sessions_df["date"] >= today_ts - pd.Timedelta(days=13)]
        total_week = last7["minutes"].sum()
        previous_week = sessions_df[(sessions_df["date"] >= today_ts - pd.Timedelta(days=13)) & (sessions_df["date"] < today_ts - pd.Timedelta(days=6))]["minutes"].sum()
        subject_totals = sessions_df.groupby("subject")["minutes"].sum().sort_values(ascending=False)
        insights = []
        if total_week == 0:
            insights.append("No study time logged in the last 7 days. Try a focused 20-minute session today.")
        else:
            insights.append(f"You logged **{total_week/60:.1f} hours** in the last 7 days.")
        if previous_week > 0:
            change = (total_week - previous_week) / previous_week * 100
            if change >= 0:
                insights.append(f"Your logged study time is **{change:.0f}% higher** than the previous 7-day period.")
            else:
                insights.append(f"Your logged study time is **{abs(change):.0f}% lower** than the previous 7-day period. Consider scheduling short sessions.")
        if not subject_totals.empty:
            top = subject_totals.index[0]
            insights.append(f"**{top}** has the most recorded study time ({subject_totals.iloc[0]/60:.1f} hours).")
            least = subject_totals.index[-1]
            if least != top:
                insights.append(f"**{least}** has the least recorded time. If it is important this week, consider adding a session.")
        pending = [t for t in tasks if not t.get("done")]
        overdue = [t for t in pending if t.get("due_date") and t["due_date"] < str(date.today())]
        if overdue:
            insights.append(f"You have **{len(overdue)} overdue task(s)**. Consider rescheduling or completing one first.")
        for item in insights:
            st.markdown(f"- {item}")
        st.markdown("### Daily study trend")
        daily = sessions_df.groupby(sessions_df["date"].dt.date)["hours"].sum().sort_index()
        st.line_chart(daily)
        st.markdown("### Time by subject")
        st.bar_chart(subject_totals / 60)

elif page == "About":
    st.subheader("About FocusFlow")
    st.write("FocusFlow is a study-planning prototype for students. It stores tasks and study sessions locally in JSON files, summarizes activity with Pandas, and produces rule-based insights.")
    st.warning("Hackathon note: this is a standalone prototype. It does not claim to be an official Alexa+ integration. See README.md for the optional MCP tool server and for the steps required to validate track eligibility.")
    st.markdown("**Privacy:** Data is stored locally in `data/tasks.json` and `data/sessions.json`. Do not commit personal data to a public repository.")
