# FocusFlow — Study Productivity Dashboard

A beginner-friendly Python project for a developer hackathon. It includes a Streamlit dashboard, task planner, study-session logger, charts, rule-based study insights, CSV export, and an optional MCP tool server.

> **Track/eligibility honesty:** This is a standalone prototype plus an MCP server. It is **not** an official Alexa+ integration and does not by itself prove hackathon track compliance. Before submission, check the current official hackathon rules/resources and make any required product-specific integration. Do not claim official Alexa+ compatibility unless you have tested it and the organizers' rules support that claim.

## Features

- Overview metrics: total study time, last-7-day study time, task completion.
- Create, complete, and delete study tasks.
- Log study sessions with subject, duration, date, and notes.
- Study time charts by subject and over time.
- Rule-based recommendations from recorded activity.
- CSV download for session history.
- Optional MCP tools for listing/adding/completing tasks, logging sessions, and getting a summary.
- Local JSON storage. Demo data is created automatically on first run.

## Requirements

- macOS (including Apple Silicon), Windows, or Linux
- Python 3.10+ recommended
- VS Code optional

## Run the dashboard

Open Terminal in this folder and run:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

A browser tab should open. If not, Streamlit prints a local address (usually `http://localhost:8501`).

### Windows activation

```powershell
.venv\Scripts\Activate.ps1
```

## Run the MCP server (optional)

In a **second terminal**, activate the same environment and run:

```bash
python mcp_server.py
```

The MCP SDK's Streamable HTTP server normally listens locally and exposes the `/mcp` endpoint. Confirm the exact host, port, and transport settings for the MCP SDK version you install. This local server is not automatically reachable by an external assistant; remote deployment, HTTPS, authentication/security, and client configuration may be required by your intended integration.

### Available MCP tools

- `list_tasks(include_completed=True)`
- `add_task(title, subject="General", due_date="", priority="Medium")`
- `complete_task(task_id)`
- `log_study_session(subject, minutes, notes="", session_date="")`
- `get_study_summary()`

The dashboard and MCP server share the JSON files in `data/`. Keep this data private; `.gitignore` excludes the JSON files from Git.

## Suggested demo flow (under 3 minutes)

1. Open the Overview and point out the study metrics.
2. Add a task, then mark it complete.
3. Log a study session.
4. Show the charts and Study Insights.
5. Download the CSV.
6. If you have validated the MCP setup, demonstrate one MCP tool call and explain what it enables.

## Before public GitHub submission

1. Remove any personal or sensitive data from the JSON files.
2. Test the app from a clean environment using the commands above.
3. Add screenshots or a short GIF to this README if useful.
4. Verify hackathon-specific track requirements and submission checklist on the official Devpost page.
5. Record a demo video under 3 minutes.
6. Submit a public repository, demo video, and product feedback as required by the event.

## Project structure

```text
FocusFlow_Hackathon_Starter/
├── app.py
├── mcp_server.py
├── requirements.txt
├── README.md
├── .gitignore
└── data/
    └── .gitkeep
```

## Limitations / next steps

- Insights are deterministic rules, not a trained AI model.
- No user accounts or cloud database are included.
- MCP server is intended for local development; secure remote deployment is not included.
- Power BI is not required to run the app; charts are rendered inside Streamlit.
- Track compliance must be checked against the current event rules and tested with the actual supported product/developer workflow.
