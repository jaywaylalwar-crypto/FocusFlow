"""Optional FocusFlow MCP server using the Python MCP SDK.

This exposes simple study-planning tools over Streamable HTTP. It is a standalone
MCP server, not an official Alexa+ integration. Validate the hackathon's current
track rules and connection requirements before claiming compatibility.
"""
from datetime import date
from pathlib import Path
import json
from mcp.server.fastmcp import FastMCP

BASE = Path(__file__).parent
DATA = BASE / "data"
TASKS = DATA / "tasks.json"
SESSIONS = DATA / "sessions.json"

mcp = FastMCP("FocusFlow", stateless_http=True)

def read_json(path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return default

def write_json(path, value):
    DATA.mkdir(exist_ok=True)
    path.write_text(json.dumps(value, indent=2))

@mcp.tool()
def list_tasks(include_completed: bool = True) -> list[dict]:
    """List FocusFlow study tasks, optionally excluding completed tasks."""
    tasks = read_json(TASKS, [])
    return tasks if include_completed else [t for t in tasks if not t.get("done", False)]

@mcp.tool()
def add_task(title: str, subject: str = "General", due_date: str = "", priority: str = "Medium") -> dict:
    """Add a study task. due_date should be YYYY-MM-DD or empty; priority is High, Medium, or Low."""
    if not title.strip():
        return {"ok": False, "error": "Task title cannot be empty."}
    if due_date:
        try:
            date.fromisoformat(due_date)
        except ValueError:
            return {"ok": False, "error": "due_date must use YYYY-MM-DD format."}
    if priority not in {"High", "Medium", "Low"}:
        return {"ok": False, "error": "priority must be High, Medium, or Low."}
    tasks = read_json(TASKS, [])
    next_id = max([t.get("id", 0) for t in tasks], default=0) + 1
    task = {"id": next_id, "title": title.strip(), "subject": subject.strip() or "General",
            "due_date": due_date, "priority": priority, "done": False}
    tasks.append(task)
    write_json(TASKS, tasks)
    return {"ok": True, "task": task}

@mcp.tool()
def complete_task(task_id: int) -> dict:
    """Mark a task as completed by its numeric ID."""
    tasks = read_json(TASKS, [])
    for task in tasks:
        if task.get("id") == task_id:
            task["done"] = True
            write_json(TASKS, tasks)
            return {"ok": True, "task": task}
    return {"ok": False, "error": f"No task found with id {task_id}."}

@mcp.tool()
def log_study_session(subject: str, minutes: int, notes: str = "", session_date: str = "") -> dict:
    """Record a study session. minutes must be between 1 and 720; session_date is YYYY-MM-DD or empty for today."""
    if minutes < 1 or minutes > 720:
        return {"ok": False, "error": "minutes must be between 1 and 720."}
    if not session_date:
        session_date = str(date.today())
    try:
        date.fromisoformat(session_date)
    except ValueError:
        return {"ok": False, "error": "session_date must use YYYY-MM-DD format."}
    sessions = read_json(SESSIONS, [])
    entry = {"date": session_date, "subject": subject.strip() or "General",
             "minutes": int(minutes), "notes": notes.strip()}
    sessions.append(entry)
    write_json(SESSIONS, sessions)
    return {"ok": True, "session": entry}

@mcp.tool()
def get_study_summary() -> dict:
    """Return total logged study time, task completion, and time spent by subject."""
    tasks = read_json(TASKS, [])
    sessions = read_json(SESSIONS, [])
    minutes = sum(int(s.get("minutes", 0)) for s in sessions)
    by_subject = {}
    for s in sessions:
        subject = s.get("subject", "General")
        by_subject[subject] = by_subject.get(subject, 0) + int(s.get("minutes", 0))
    completed = sum(1 for t in tasks if t.get("done"))
    return {"total_minutes": minutes, "total_hours": round(minutes / 60, 2),
            "tasks_total": len(tasks), "tasks_completed": completed,
            "minutes_by_subject": by_subject}

if __name__ == "__main__":
    # Streamable HTTP transport; default local endpoint is normally /mcp.
    mcp.run(transport="streamable-http")
